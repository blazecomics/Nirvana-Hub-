# Nirvana Hub deploy
1. Push this folder to GitHub, import into Netlify (build command: none, publish dir: .). Netlify installs @netlify/blobs from package.json.
2. Netlify > Environment variables: PAYSTACK_SECRET_KEY, DATAMART_API_KEY, SITE_URL (see .env.example).
3. Paystack dashboard > Settings > API & Webhooks: set Webhook URL to https://YOUR-SITE/api/paystack-webhook
4. deliver() already targets https://api.datamartgh.shop/api/developer/purchase. If you enabled a second secret or a reference prefix in DataMart, set DATAMART_API_SECRET / DATAMART_REF_PREFIX. Test with a Paystack test key and a 1GB order first.
5. Withdrawals: open https://YOUR-SITE/admin.html, enter ADMIN_TOKEN, enter an amount. Money only ever goes to WITHDRAW_PHONE.
